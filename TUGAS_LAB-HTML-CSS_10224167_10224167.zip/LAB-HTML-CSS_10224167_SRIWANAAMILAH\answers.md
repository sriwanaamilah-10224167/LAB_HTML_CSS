# Jawaban Praktikum: <Nama> (<NIM>)

## Bagian 1: Pemanasan
1. Selector: nav a.active:hover
   Deklarasi: color: red;
   Property: color
   Value: red
   Pseudo-class: :hove
2. Block: p, li, h2.
   Inline: span, a, strong
3. Paragraf A dan B menjadi hijau karena keduanya merupakan elemen p yang berada di dalam elemen dengan class box.
4. Warnanya merah karena selector #title memiliki specificity paling tinggi dibandingkan selector .heading dan h1.
5. Tag HTML tidak ditutup dengan urutan yang benar. Tag <strong> harus ditutup sebelum tag </p>, sehingga menjadi <p>Hello <strong>world</strong></p>.

## Bagian 3: Prediksi Selector Golf
P1. (a) Weekly hack nights: biru.
(b) Bring your own laptop: oranye.
(c) © 2026 Student Affairs: biru.
P2. Urutan specificity tertinggi ke terendah:
1. #tech p
2. .club p
3. main section p
4. p

Setelah diuji (hasil sebenarnya):
hasil pengujian p1 :
(a) Weekly hack nights: hijau.
(b) Bring your own laptop: oranye.
(c) © 2026 Student Affairs: biru.

## Bagian 4: Box model
Q1 (content-box):
Q2 (border-box):
Pengecekan DevTools:

## Bagian 5: Tabel debug
| # | Baris | Bug | Perbaikan | Cara menemukannya |
|---|-------|-----|-----------|-------------------|

## Bagian 6: Tabel Code Review
| # | Baris | Masalah | Mengapa penting | Perbaikan saya |
|---|-------|---------|-----------------|----------------|

Refleksi:
1.
2.
3.

## Bagian 7: Exit ticket
1.
2.
3.
```